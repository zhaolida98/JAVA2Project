package application;

import javafx.beans.property.SimpleStringProperty;

public class EarthQuack_info {
	private String ID;
	private String longtitude;
	private String lantitude;
	private String depth;
	private String magnitude;
	private String region;
	private String UTC_date;
	
	
	public EarthQuack_info(String ID,String UTC_date, String lantitude,String longtitude,
			  String depth ,String magnitude, String region) {
		this.ID  = new String(ID);
		this.longtitude  = new String(longtitude);
		this.lantitude  = new String(lantitude);
		this.depth  = new String(depth);
		this.magnitude= new String(magnitude);
		this.region  = new String(region);
		this.UTC_date  = new String(UTC_date);
	}
	public String getLongtitude() {
		return longtitude;
	}
	public void setLongtitude(String longtitude) {
		this.longtitude = longtitude;
	}
	public String getLantitude() {
		return lantitude;
	}
	public void setLantitude(String lantitude) {
		this.lantitude = lantitude;
	}
	public String getDepth() {
		return depth;
	}
	public void setDepth(String depth) {
		this.depth = depth;
	}
	public String getMagnitude() {
		return magnitude;
	}
	public void setMagnitude(String magnitude) {
		this.magnitude = magnitude;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getUTC_date() {
		return UTC_date;
	}
	public void setUTC_date(String uTC_date) {
		UTC_date = uTC_date;
	}
	public String getID() {
		return ID;
	}
	
	public void setID(String id){
		this.ID = new String(id);
	}
	
	
}

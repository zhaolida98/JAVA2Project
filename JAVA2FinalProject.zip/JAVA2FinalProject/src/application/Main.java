package application;
	
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.print.DocFlavor.URL;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;


public class Main extends Application implements Initializable  {
	ArrayList<EarthQuack_info> arlist = new ArrayList<>();//��ArrayList����װString�������洢����
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("../earthquakeUI.fxml"));
			primaryStage.setTitle("�����ѯС����");
			primaryStage.setScene(new Scene(root));
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
			System.err.println("���ڳ�ʼ��");
			System.exit(0);
		}
	}
	@FXML
	TableView<EarthQuack_info> earthquackTable;

	@FXML
	TableColumn<EarthQuack_info,?> IDcol = new TableColumn<>("ID");
	
	@FXML
	TableColumn<EarthQuack_info,?> UTC_datecol= new TableColumn<>("UTC_date");
	
	@FXML
	TableColumn<EarthQuack_info,?> latitudecol= new TableColumn<>("latitude");
	
	@FXML
	TableColumn<EarthQuack_info,?> longitudecol= new TableColumn<>("longitude");
	
	@FXML
	TableColumn<EarthQuack_info,?> depthcol= new TableColumn<>("depth");
	
	@FXML
	TableColumn<EarthQuack_info,?> magnitudecol= new TableColumn<>("magnitude");
	
	@FXML
	TableColumn<EarthQuack_info,?> regioncol= new TableColumn<>("region");
	
	@FXML
	TextField  time ;
	
	@FXML
	TextField place;
	
	@FXML
	Button search;
	
	@FXML
	Button clear;
	
	@FXML
	Slider slider;
	
	  ObservableList<EarthQuack_info> data;
	@Override
	public void initialize(java.net.URL location,ResourceBundle resources){
		  try {  
	            BufferedReader reader = new BufferedReader(new FileReader("earthquakes.csv"));//��������ļ��� 
	            reader.readLine();//��һ��Ϊ������Ϣ,ע�͵� 
	            String line = null;  
	            
	            while((line=reader.readLine())!=null){  
	                String item[] = line.split(",");//CSV��ʽ�ļ�Ϊ���ŷָ����ļ���������ݶ����з� 
	                EarthQuack_info eri = new EarthQuack_info
	                		(item[0], item[1], item[2], item[3], item[4], item[5], item[6]);
	                arlist.add(eri);
	                
	            }  
	        } catch (Exception e) {  
	            e.printStackTrace(); 
	            System.err.println("shujuduru");
	        }  
		  //all the table view stuff
		data = FXCollections.observableArrayList(arlist);
		earthquackTable.setEditable(true);
		earthquackTable.getColumns().addAll
			(IDcol,UTC_datecol,latitudecol,longitudecol,depthcol,magnitudecol,regioncol);

		IDcol.setCellValueFactory(new PropertyValueFactory<>("ID"));
		UTC_datecol.setCellValueFactory(new PropertyValueFactory<>("UTC_date"));
		latitudecol.setCellValueFactory(new PropertyValueFactory<>("latitude"));
		longitudecol.setCellValueFactory(new PropertyValueFactory<>("longitude"));
		depthcol.setCellValueFactory(new PropertyValueFactory<>("depth"));
		magnitudecol.setCellValueFactory(new PropertyValueFactory<>("magnitude"));
		regioncol.setCellValueFactory(new PropertyValueFactory<>("region"));
		try{
		earthquackTable.setItems(data);
		}catch (Exception e) {
			System.err.println("adding info");
			System.exit(1);
			}
		//slider stuff
//		double mag=slider.getValue();
		//all the botton stuff
		
	}
	public static void main(String[] args) {
		launch(args);
	}
	
	public void onSearch(MouseEvent e){
		data.clear();
		String timeinfo = time.getText();
		String placeinfo = place.getText();
		String mag = String.valueOf(slider.getValue());
		ArrayList<EarthQuack_info> temp = new ArrayList<>();
		for (EarthQuack_info ind : arlist) {
			if(ind.getUTC_date().equals(timeinfo)
					||ind.getRegion().contains(placeinfo)
					||ind.getMagnitude() == mag){
				data.add(ind);
			}
			
		}
		earthquackTable.setItems(data);

	}
	public void onClear(MouseEvent me){
		time.clear();
		place.clear();
		data = FXCollections.observableArrayList(arlist);
		earthquackTable.setItems(data);
	}
	
}

